//
//  ViewController.swift
//  OnTheMoveV4
//
//  Created by user@53 on 06/02/25.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

